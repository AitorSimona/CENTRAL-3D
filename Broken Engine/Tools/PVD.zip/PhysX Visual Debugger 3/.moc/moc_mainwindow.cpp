/****************************************************************************
** Meta object code from reading C++ file 'mainwindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.10.0)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../../../PVDNext/mainwindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'mainwindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.10.0. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_PVDMainWindow_t {
    QByteArrayData data[65];
    char stringdata0[883];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_PVDMainWindow_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_PVDMainWindow_t qt_meta_stringdata_PVDMainWindow = {
    {
QT_MOC_LITERAL(0, 0, 13), // "PVDMainWindow"
QT_MOC_LITERAL(1, 14, 15), // "settingsUpdated"
QT_MOC_LITERAL(2, 30, 0), // ""
QT_MOC_LITERAL(3, 31, 12), // "enableCamera"
QT_MOC_LITERAL(4, 44, 7), // "onAbout"
QT_MOC_LITERAL(5, 52, 6), // "onOpen"
QT_MOC_LITERAL(6, 59, 6), // "onSave"
QT_MOC_LITERAL(7, 66, 15), // "onExportAllRepX"
QT_MOC_LITERAL(8, 82, 20), // "onExportSelectedRepX"
QT_MOC_LITERAL(9, 103, 19), // "onExportVisibleRepX"
QT_MOC_LITERAL(10, 123, 6), // "onExit"
QT_MOC_LITERAL(11, 130, 14), // "onEnableCamera"
QT_MOC_LITERAL(12, 145, 12), // "onClipCamera"
QT_MOC_LITERAL(13, 158, 15), // "onDefaultCamera"
QT_MOC_LITERAL(14, 174, 15), // "onTrackSelected"
QT_MOC_LITERAL(15, 190, 14), // "onSceneChanged"
QT_MOC_LITERAL(16, 205, 3), // "val"
QT_MOC_LITERAL(17, 209, 17), // "onFrameSliderMove"
QT_MOC_LITERAL(18, 227, 23), // "onFrameSelectedFromPlot"
QT_MOC_LITERAL(19, 251, 16), // "onPlotFrameGraph"
QT_MOC_LITERAL(20, 268, 8), // "onManual"
QT_MOC_LITERAL(21, 277, 13), // "onReportIssue"
QT_MOC_LITERAL(22, 291, 13), // "onPlayClicked"
QT_MOC_LITERAL(23, 305, 15), // "onRewindClicked"
QT_MOC_LITERAL(24, 321, 22), // "onRewindForwardClicked"
QT_MOC_LITERAL(25, 344, 18), // "onNextFrameClicked"
QT_MOC_LITERAL(26, 363, 22), // "onPreviousFrameClicked"
QT_MOC_LITERAL(27, 386, 11), // "onGotoFrame"
QT_MOC_LITERAL(28, 398, 10), // "onSettings"
QT_MOC_LITERAL(29, 409, 21), // "onResetVisualSettings"
QT_MOC_LITERAL(30, 431, 13), // "onFindObjects"
QT_MOC_LITERAL(31, 445, 12), // "onFindEvents"
QT_MOC_LITERAL(32, 458, 9), // "playFrame"
QT_MOC_LITERAL(33, 468, 5), // "frame"
QT_MOC_LITERAL(34, 474, 13), // "playNextFrame"
QT_MOC_LITERAL(35, 488, 15), // "onNewConnection"
QT_MOC_LITERAL(36, 504, 12), // "onDisconnect"
QT_MOC_LITERAL(37, 517, 5), // "onNet"
QT_MOC_LITERAL(38, 523, 12), // "onTabChanged"
QT_MOC_LITERAL(39, 536, 3), // "tab"
QT_MOC_LITERAL(40, 540, 10), // "onCloseTab"
QT_MOC_LITERAL(41, 551, 11), // "onSplitClip"
QT_MOC_LITERAL(42, 563, 13), // "onTrimToStart"
QT_MOC_LITERAL(43, 577, 11), // "onTrimToEnd"
QT_MOC_LITERAL(44, 589, 13), // "onClipChanges"
QT_MOC_LITERAL(45, 603, 17), // "QTableWidgetItem*"
QT_MOC_LITERAL(46, 621, 4), // "item"
QT_MOC_LITERAL(47, 626, 22), // "onClipTableContextMenu"
QT_MOC_LITERAL(48, 649, 1), // "p"
QT_MOC_LITERAL(49, 651, 15), // "onClipTableSave"
QT_MOC_LITERAL(50, 667, 17), // "onClipTableDelete"
QT_MOC_LITERAL(51, 685, 24), // "onAllowConnectionClicked"
QT_MOC_LITERAL(52, 710, 19), // "onDisconnectClicked"
QT_MOC_LITERAL(53, 730, 15), // "unableToSetPort"
QT_MOC_LITERAL(54, 746, 20), // "onContextMenuProfile"
QT_MOC_LITERAL(55, 767, 5), // "point"
QT_MOC_LITERAL(56, 773, 26), // "onContextMenuThreadProfile"
QT_MOC_LITERAL(57, 800, 12), // "onLoadValues"
QT_MOC_LITERAL(58, 813, 8), // "uint64_t"
QT_MOC_LITERAL(59, 822, 7), // "instPtr"
QT_MOC_LITERAL(60, 830, 7), // "int32_t"
QT_MOC_LITERAL(61, 838, 6), // "propId"
QT_MOC_LITERAL(62, 845, 11), // "onPlotEvent"
QT_MOC_LITERAL(63, 857, 17), // "onPlotEventAllTid"
QT_MOC_LITERAL(64, 875, 7) // "onPaint"

    },
    "PVDMainWindow\0settingsUpdated\0\0"
    "enableCamera\0onAbout\0onOpen\0onSave\0"
    "onExportAllRepX\0onExportSelectedRepX\0"
    "onExportVisibleRepX\0onExit\0onEnableCamera\0"
    "onClipCamera\0onDefaultCamera\0"
    "onTrackSelected\0onSceneChanged\0val\0"
    "onFrameSliderMove\0onFrameSelectedFromPlot\0"
    "onPlotFrameGraph\0onManual\0onReportIssue\0"
    "onPlayClicked\0onRewindClicked\0"
    "onRewindForwardClicked\0onNextFrameClicked\0"
    "onPreviousFrameClicked\0onGotoFrame\0"
    "onSettings\0onResetVisualSettings\0"
    "onFindObjects\0onFindEvents\0playFrame\0"
    "frame\0playNextFrame\0onNewConnection\0"
    "onDisconnect\0onNet\0onTabChanged\0tab\0"
    "onCloseTab\0onSplitClip\0onTrimToStart\0"
    "onTrimToEnd\0onClipChanges\0QTableWidgetItem*\0"
    "item\0onClipTableContextMenu\0p\0"
    "onClipTableSave\0onClipTableDelete\0"
    "onAllowConnectionClicked\0onDisconnectClicked\0"
    "unableToSetPort\0onContextMenuProfile\0"
    "point\0onContextMenuThreadProfile\0"
    "onLoadValues\0uint64_t\0instPtr\0int32_t\0"
    "propId\0onPlotEvent\0onPlotEventAllTid\0"
    "onPaint"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_PVDMainWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      52,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       2,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    0,  274,    2, 0x06 /* Public */,
       3,    1,  275,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
       4,    0,  278,    2, 0x0a /* Public */,
       5,    0,  279,    2, 0x0a /* Public */,
       6,    0,  280,    2, 0x0a /* Public */,
       7,    0,  281,    2, 0x0a /* Public */,
       8,    0,  282,    2, 0x0a /* Public */,
       9,    0,  283,    2, 0x0a /* Public */,
      10,    0,  284,    2, 0x0a /* Public */,
      11,    1,  285,    2, 0x0a /* Public */,
      12,    0,  288,    2, 0x0a /* Public */,
      13,    0,  289,    2, 0x0a /* Public */,
      14,    1,  290,    2, 0x0a /* Public */,
      15,    1,  293,    2, 0x0a /* Public */,
      17,    1,  296,    2, 0x0a /* Public */,
      18,    1,  299,    2, 0x0a /* Public */,
      19,    0,  302,    2, 0x0a /* Public */,
      20,    0,  303,    2, 0x0a /* Public */,
      21,    0,  304,    2, 0x0a /* Public */,
      22,    0,  305,    2, 0x0a /* Public */,
      23,    0,  306,    2, 0x0a /* Public */,
      24,    0,  307,    2, 0x0a /* Public */,
      25,    0,  308,    2, 0x0a /* Public */,
      26,    0,  309,    2, 0x0a /* Public */,
      27,    0,  310,    2, 0x0a /* Public */,
      28,    0,  311,    2, 0x0a /* Public */,
      29,    0,  312,    2, 0x0a /* Public */,
      30,    0,  313,    2, 0x0a /* Public */,
      31,    0,  314,    2, 0x0a /* Public */,
      32,    1,  315,    2, 0x0a /* Public */,
      34,    0,  318,    2, 0x0a /* Public */,
      35,    0,  319,    2, 0x0a /* Public */,
      36,    0,  320,    2, 0x0a /* Public */,
      37,    0,  321,    2, 0x0a /* Public */,
      38,    1,  322,    2, 0x0a /* Public */,
      40,    1,  325,    2, 0x0a /* Public */,
      41,    0,  328,    2, 0x0a /* Public */,
      42,    0,  329,    2, 0x0a /* Public */,
      43,    0,  330,    2, 0x0a /* Public */,
      44,    1,  331,    2, 0x0a /* Public */,
      47,    1,  334,    2, 0x0a /* Public */,
      49,    0,  337,    2, 0x0a /* Public */,
      50,    0,  338,    2, 0x0a /* Public */,
      51,    0,  339,    2, 0x0a /* Public */,
      52,    0,  340,    2, 0x0a /* Public */,
      53,    0,  341,    2, 0x0a /* Public */,
      54,    1,  342,    2, 0x0a /* Public */,
      56,    1,  345,    2, 0x0a /* Public */,
      57,    2,  348,    2, 0x0a /* Public */,
      62,    0,  353,    2, 0x0a /* Public */,
      63,    0,  354,    2, 0x0a /* Public */,
      64,    0,  355,    2, 0x0a /* Public */,

 // signals: parameters
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Bool,    2,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void, QMetaType::Int,   16,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   33,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::Int,   39,
    QMetaType::Void, QMetaType::Int,   39,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, 0x80000000 | 45,   46,
    QMetaType::Void, QMetaType::QPoint,   48,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QPoint,   55,
    QMetaType::Void, QMetaType::QPoint,   55,
    QMetaType::Void, 0x80000000 | 58, 0x80000000 | 60,   59,   61,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void PVDMainWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        PVDMainWindow *_t = static_cast<PVDMainWindow *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->settingsUpdated(); break;
        case 1: _t->enableCamera((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 2: _t->onAbout(); break;
        case 3: _t->onOpen(); break;
        case 4: _t->onSave(); break;
        case 5: _t->onExportAllRepX(); break;
        case 6: _t->onExportSelectedRepX(); break;
        case 7: _t->onExportVisibleRepX(); break;
        case 8: _t->onExit(); break;
        case 9: _t->onEnableCamera((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 10: _t->onClipCamera(); break;
        case 11: _t->onDefaultCamera(); break;
        case 12: _t->onTrackSelected((*reinterpret_cast< bool(*)>(_a[1]))); break;
        case 13: _t->onSceneChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 14: _t->onFrameSliderMove((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 15: _t->onFrameSelectedFromPlot((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 16: _t->onPlotFrameGraph(); break;
        case 17: _t->onManual(); break;
        case 18: _t->onReportIssue(); break;
        case 19: _t->onPlayClicked(); break;
        case 20: _t->onRewindClicked(); break;
        case 21: _t->onRewindForwardClicked(); break;
        case 22: _t->onNextFrameClicked(); break;
        case 23: _t->onPreviousFrameClicked(); break;
        case 24: _t->onGotoFrame(); break;
        case 25: _t->onSettings(); break;
        case 26: _t->onResetVisualSettings(); break;
        case 27: _t->onFindObjects(); break;
        case 28: _t->onFindEvents(); break;
        case 29: _t->playFrame((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 30: _t->playNextFrame(); break;
        case 31: _t->onNewConnection(); break;
        case 32: _t->onDisconnect(); break;
        case 33: _t->onNet(); break;
        case 34: _t->onTabChanged((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 35: _t->onCloseTab((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 36: _t->onSplitClip(); break;
        case 37: _t->onTrimToStart(); break;
        case 38: _t->onTrimToEnd(); break;
        case 39: _t->onClipChanges((*reinterpret_cast< QTableWidgetItem*(*)>(_a[1]))); break;
        case 40: _t->onClipTableContextMenu((*reinterpret_cast< QPoint(*)>(_a[1]))); break;
        case 41: _t->onClipTableSave(); break;
        case 42: _t->onClipTableDelete(); break;
        case 43: _t->onAllowConnectionClicked(); break;
        case 44: _t->onDisconnectClicked(); break;
        case 45: _t->unableToSetPort(); break;
        case 46: _t->onContextMenuProfile((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 47: _t->onContextMenuThreadProfile((*reinterpret_cast< const QPoint(*)>(_a[1]))); break;
        case 48: _t->onLoadValues((*reinterpret_cast< uint64_t(*)>(_a[1])),(*reinterpret_cast< int32_t(*)>(_a[2]))); break;
        case 49: _t->onPlotEvent(); break;
        case 50: _t->onPlotEventAllTid(); break;
        case 51: _t->onPaint(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            typedef void (PVDMainWindow::*_t)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PVDMainWindow::settingsUpdated)) {
                *result = 0;
                return;
            }
        }
        {
            typedef void (PVDMainWindow::*_t)(bool );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&PVDMainWindow::enableCamera)) {
                *result = 1;
                return;
            }
        }
    }
}

const QMetaObject PVDMainWindow::staticMetaObject = {
    { &QMainWindow::staticMetaObject, qt_meta_stringdata_PVDMainWindow.data,
      qt_meta_data_PVDMainWindow,  qt_static_metacall, nullptr, nullptr}
};


const QMetaObject *PVDMainWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *PVDMainWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_PVDMainWindow.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int PVDMainWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 52)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 52;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 52)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 52;
    }
    return _id;
}

// SIGNAL 0
void PVDMainWindow::settingsUpdated()
{
    QMetaObject::activate(this, &staticMetaObject, 0, nullptr);
}

// SIGNAL 1
void PVDMainWindow::enableCamera(bool _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
